import setuptools
with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="blogs",
    version="1.0.0",
    author="youjia4321",
    author_email="youjia4321@163.com",
    description="A small example package",
    install_requires = ['django==2.1.2',
    'django-pure-pagination==0.3.0',
    'django-ranged-response==0.2.0',
    'django-simple-captcha==0.5.9',
    'Pillow==5.3.0',
    'pip==18.1',
    'psycopg2==2.7.5',
    'psycopg2-binary==2.7.5',
    'pytz==2018.5',
    'setuptools==40.4.3',
    'six==1.11.0',
    'wheel==0.32.1'],
    url="https://github.com/youjia4321/django_blogs",
    include_package_data = True,
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3.6",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
