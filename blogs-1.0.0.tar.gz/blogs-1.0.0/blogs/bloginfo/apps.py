from django.apps import AppConfig


class BloginfoConfig(AppConfig):
    name = 'bloginfo'
